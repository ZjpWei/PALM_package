## ---- echo=FALSE, fig.cap="Schematic overview of PALM for meta-analysis.", fig.align="center"----
knitr::include_graphics("./Intro.png")

## ----getPackage, echo=TRUE----------------------------------------------------
if(!require("PALM", quietly = TRUE)){
  devtools::install_github("ZjpWei/PALM_package")
}

## ----load, echo=TRUE, message=FALSE, warning=FALSE----------------------------
library("PALM")
library("ggplot2")
library("cowplot")
library("tidyverse")
library("DT")
options(DT.options = list(
  initComplete = JS("function(settings, json) {",
  "$(this.api().table().header()).css({'background-color': 
  '#000', 'color': '#fff'});","}")))

## ----echo=TRUE----------------------------------------------------------------
## Load CRC data
data("CRC_data")
CRC_abd <- CRC_data$CRC_abd
CRC_meta <- CRC_data$CRC_meta

