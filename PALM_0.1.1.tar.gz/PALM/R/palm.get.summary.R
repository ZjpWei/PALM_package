#' @title Generate PALM summary statistics for individual studies
#'
#' @description
#' This function takes the output object from the \code{palm.null.model} function and
#' constructs summary statistics for the covariates of interest in each study.
#' The resulting output can be directly used as input to the \code{palm.meta.summary} function
#' to perform meta-analysis.
#'
#' @param null.obj The output object from the \code{palm.null.model} function.
#' @param ... Additional arguments passed to \code{palm}.
#' In \code{covariate.interest} and \code{cluster}, the order of samples must match
#' the order in \code{feature.counts} used in the \code{palm.null.model} function.
#'
#' @return
#' A list containing one component per study. Each component includes the following elements:
#' \item{est}{A matrix containing the association effect estimates for the study.
#' Rows correspond to microbial feature IDs and columns correspond to covariate IDs.}
#' \item{stderr}{A matrix containing the standard errors of the association effect estimates for the study.
#' Rows correspond to microbial feature IDs and columns correspond to covariate IDs.}
#' \item{n}{The sample size for the study.}
#'
#' @seealso
#' \code{\link{palm.null.model}},
#' \code{\link{palm.meta.summary}},
#' \code{\link{palm}}
#'
#' @import dplyr Rcpp
#' @useDynLib PALM, .registration = TRUE
#' @export
#'
#' @examples
#' \donttest{
#' library(PALM)
#' data("CRC_data", package = "PALM")
#' CRC_abd <- CRC_data$CRC_abd
#' CRC_meta <- CRC_data$CRC_meta
#'
#' ########## Generate summary statistics ##########
#' feature.counts <- list()
#' covariate.interest <- list()
#' for (d in unique(CRC_meta$Study)) {
#'   feature.counts[[d]] <- CRC_abd[CRC_meta$Sample_ID[CRC_meta$Study == d], ]
#'   disease <- as.numeric(CRC_meta$Group[CRC_meta$Study == d] == "CRC")
#'   names(disease) <- CRC_meta$Sample_ID[CRC_meta$Study == d]
#'   covariate.interest[[d]] <- matrix(disease, ncol = 1,
#'                                     dimnames = list(names(disease), "disease"))
#' }
#'
#' null.obj <- palm.null.model(feature.counts = feature.counts)
#' summary.stats <- palm.get.summary(null.obj = null.obj,
#'                                   covariate.interest = covariate.interest)
#' }

palm.get.summary <- function(null.obj,
                             covariate.interest,
                             cluster = NULL,
                             correct = "median") {

  if (any(sapply(null.obj, function(d) d$abd))) {
    correct <- NULL
    warning(
      "At least one study includes features with an average proportion larger than 90%. Forcing `correct = NULL`."
    )
  }

  #=== Check input data ===#
  if(length(null.obj) == 1){
    if(!is.matrix(covariate.interest)){
      stop("null.obj only includes one study, covariate.interest should be a matrix.")
    }
    if(!is.null(cluster)){
      if(!is.vector(cluster)){
        stop("null.obj only includes one study, cluster should be a vector.")
      }
    }
    covariate.interest <- setNames(list(covariate.interest), names(null.obj))
    cluster <- setNames(list(cluster), names(null.obj))
  }

  study.ID <- names(null.obj)
  feature.ID <- NULL
  cov.names <- NULL
  for(d in names(null.obj)){
    feature.ID <- c(feature.ID, colnames(null.obj[[d]]$Y_I))
    if(is.null(colnames(covariate.interest[[d]]))){
      stop("covariate.interest is not a matrix with column names. Please check your data.")
    }else{
      covariate.interest[[d]] <- data.frame(covariate.interest[[d]])
      cov.names <- c(cov.names, colnames(covariate.interest[[d]]))
    }
  }
  feature.ID <- unique(feature.ID)
  cov.names <- unique(cov.names)
  K <- length(feature.ID)

  ## Match rel.data, covariate.interest and covariate.adjust.
  SUB.id <- list()
  for(d in study.ID){
    if(is.null(covariate.interest[[d]])){
      stop("Study IDs in rel.data and covariate.interest don't match, please check the input data.")
    }
    if(!is.data.frame(covariate.interest[[d]])){
      stop("covariate.interest is not a list of data frames.\n")
    }
    if(nrow(covariate.interest[[d]]) != (nrow(null.obj[[d]]$Y_I) + length(null.obj[[d]]$rm.sample.idx))){
      stop("The sample size of covariate.interest is not correct, please check the input data.")
    }else{
      if(length(null.obj[[d]]$rm.sample.idx) > 0){
        covariate.interest[[d]] <- covariate.interest[[d]] %>% dplyr::slice(-null.obj[[d]]$rm.sample.idx)
      }
      rownames(covariate.interest[[d]]) <- rownames(null.obj[[d]]$Y_I)
    }
    if(is.null(cluster[[d]])){
      cluster.nm <- rownames(null.obj[[d]]$Y_I)
      names(cluster.nm) <- rownames(null.obj[[d]]$Y_I)
      SUB.id[[d]] <- as.numeric(factor(cluster.nm))
    }else{
      if(!is.vector(cluster[[d]])){
        stop("cluster is not a list of vectors. \n")
      }
      if(length(cluster[[d]]) != (nrow(null.obj[[d]]$Y_I) + length(null.obj[[d]]$rm.sample.idx))){
        stop("The sample size of cluster is not correct, please check the input data. \n")
      }else{
        if(length(null.obj[[d]]$rm.sample.idx) > 0){
          cluster[[d]] <- (cluster[[d]])[-null.obj[[d]]$rm.sample.idx]
        }
      }
      cluster.nm <- cluster[[d]]
      names(cluster.nm) <- rownames(null.obj[[d]]$Y_I)
      SUB.id[[d]] <- as.numeric(factor(cluster.nm))
    }
  }

  Sample.info <- list()
  Cov.int.info <- list()
  for(d in study.ID){
    cov.int.nm <- colnames(covariate.interest[[d]])
    sample.ids <- rownames(null.obj[[d]]$Y_I)
    kp.sample.mat <- matrix(FALSE, nrow = length(sample.ids), ncol = length(cov.int.nm), dimnames = list(sample.ids, cov.int.nm))
    for(cov.name in cov.int.nm){
      kp.sample.mat[rownames(covariate.interest[[d]]),cov.name] <- TRUE
    }
    Sample.info[[d]] <- kp.sample.mat
    Cov.int.info[[d]] <- cov.int.nm
  }

  ## Get summary statistics by palm_rcpp
  summary.stat.study <- palm_rcpp(null_obj = null.obj, covariate_interest = covariate.interest,
                                  SUB_id = SUB.id,
                                  study_ID = study.ID, feature_ID = feature.ID, Cov_int_info = Cov.int.info,
                                  Sample_info = Sample.info)

  for(d in study.ID){
    summary.stat.study[[d]]$n <- nrow(covariate.interest[[d]])
  }

  ## Correct summary statistics
  if(!is.null(correct)){
    covariate.interest <- unique(unlist(lapply(summary.stat.study, function(d){colnames(d$est)})))
    if(correct == "median"){
      for(cov.int in covariate.interest){
        for(d in study.ID){
          if(cov.int %in% colnames(summary.stat.study[[d]]$est)){
            ## adjust estimates
            min.delta <- median( - summary.stat.study[[d]]$est[,cov.int], na.rm = TRUE)
            non.na <- !is.na(summary.stat.study[[d]]$est[,cov.int])
            summary.stat.study[[d]]$est[non.na,cov.int] <- summary.stat.study[[d]]$est[non.na,cov.int] + min.delta

            ## adjust variances
            adjust.part <- sum(non.na) / (2 * sum(1 / sqrt(2*pi) / summary.stat.study[[d]]$stderr[non.na,cov.int]))^2
            summary.stat.study[[d]]$stderr[non.na,cov.int] <- sqrt((summary.stat.study[[d]]$stderr[non.na,cov.int])^2 + adjust.part)
          }
        }
      }
    }else{
      for(cov.int in covariate.interest){
        summary.score.RA <- lapply(summary.stat.study, function(d){
          if(cov.int %in% colnames(d$est)){
            return(list(est = d$est[,cov.int,drop=FALSE], stderr = d$stderr[,cov.int,drop=FALSE], n = d$n))
          }
        })
        PALM_tune <- palm_tune(summary.stats = summary.score.RA, output.best.one = TRUE, verbose = FALSE)
        names(PALM_tune[[1]]$delta) <- names(summary.score.RA)

        for(d in study.ID){
          if(cov.int %in% colnames(summary.stat.study[[d]]$est)){
            ## adjust estimates
            min.delta <- PALM_tune[[1]]$delta[d]
            non.na <- !is.na(summary.stat.study[[d]]$est[,cov.int])
            summary.stat.study[[d]]$est[non.na,cov.int] <- summary.stat.study[[d]]$est[non.na,cov.int] + min.delta

            ## adjust variances
            adjust.part <- sum(non.na) / (2 * sum(1 / sqrt(2*pi) / summary.stat.study[[d]]$stderr[non.na,cov.int]))^2
            summary.stat.study[[d]]$stderr[non.na,cov.int] <- sqrt((summary.stat.study[[d]]$stderr[non.na,cov.int])^2 + adjust.part)
          }
        }
      }
    }
  }
  return(summary.stat.study)
}
